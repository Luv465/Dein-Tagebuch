# Mein Tagebuch

Eine einfache Tagebuch-App fürs iPhone (ab iOS 14). Du kannst Einträge
schreiben, ihnen ein Datum geben und mehrere Bilder anhängen. Alles wird
**lokal auf dem Gerät** gespeichert – nichts wird ins Internet geschickt.

## Funktionen

- Einträge mit Titel, freiem Text und Datum/Uhrzeit
- Mehrere Bilder pro Eintrag (aus der Fotobibliothek oder direkt per Kamera)
- Übersichtsliste mit Vorschaubild, nach Datum sortiert
- Einträge bearbeiten und löschen
- Komplett offline, reines SwiftUI, keine externen Bibliotheken

## Die IPA bauen (über GitHub, ohne eigenen Mac)

Du brauchst keinen Mac. GitHub baut die IPA für dich auf deren Apple-Rechnern.

1. **Neues Repository anlegen** auf https://github.com (z. B. `MeinTagebuch`).
2. **Diese Dateien hochladen.** Entweder über „Add file → Upload files" im
   Browser (den gesamten Ordnerinhalt reinziehen), oder per Git:
   ```bash
   git init
   git add .
   git commit -m "Erste Version"
   git branch -M main
   git remote add origin https://github.com/DEIN-NAME/MeinTagebuch.git
   git push -u origin main
   ```
3. Nach dem Push startet der Build **automatisch**. Du findest ihn im
   Reiter **„Actions"** deines Repositories. Dauert ein paar Minuten.
   (Falls er nicht von allein startet: Actions → „Build unsigned IPA" →
   „Run workflow".)
4. Ist der Build grün, öffne ihn und lade unten unter **„Artifacts"** die
   Datei **`MeinTagebuch-unsigned-ipa`** herunter. Darin liegt die
   `MeinTagebuch.ipa`.

## Die IPA installieren

Die IPA ist **unsigniert**. Auf einem gejailbreakten iPhone kannst du sie
mit den üblichen Werkzeugen installieren, z. B.:

- **TrollStore** (wenn dein Jailbreak/iOS das unterstützt) – unsignierte
  IPAs lassen sich dauerhaft installieren.
- **AppSync Unified** (aus Cydia/Sileo) + ein Installer wie Filza oder
  `ldid`, um die unsignierte App zu akzeptieren.
- Alternativ mit einem eigenen Signierer wie **AltStore/SideStore** oder
  **Sideloadly**, falls du lieber mit eigenem Zertifikat signierst statt
  die unsignierte Variante zu nehmen.

Welcher Weg der richtige ist, hängt von deiner genauen iOS-Version und
deinem Jailbreak ab. Sag mir, was du nutzt, dann nenne ich dir die
passenden Schritte.

## Projektaufbau

```
MeinTagebuch/
├─ MeinTagebuch.xcodeproj/        Xcode-Projekt
├─ MeinTagebuch/
│  ├─ MeinTagebuchApp.swift       App-Einstieg
│  ├─ JournalEntry.swift          Datenmodell eines Eintrags
│  ├─ JournalStore.swift          Speichern/Laden auf der Festplatte
│  ├─ ContentView.swift           Übersichtsliste
│  ├─ EntryEditView.swift         Eintrag schreiben/bearbeiten
│  ├─ ImagePicker.swift           Bildauswahl (iOS-14-kompatibel)
│  ├─ Assets.xcassets/            App-Icon & Farben
│  └─ Info.plist                  App-Konfiguration & Berechtigungen
└─ .github/workflows/build.yml    Automatischer IPA-Build
```

## Wo liegen meine Daten?

Im Documents-Ordner der App: `entries.json` für die Texte, ein
`Images/`-Unterordner für die Fotos. Beim Deinstallieren der App werden
sie mitgelöscht – es gibt (noch) keine Backup-/Export-Funktion. Sag
Bescheid, wenn du Export (z. B. als PDF) oder iCloud-Sync möchtest.
